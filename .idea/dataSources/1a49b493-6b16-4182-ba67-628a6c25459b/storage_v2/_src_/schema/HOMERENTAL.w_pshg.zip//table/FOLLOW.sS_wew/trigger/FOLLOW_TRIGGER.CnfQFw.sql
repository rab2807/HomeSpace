create trigger FOLLOW_TRIGGER
    after insert or delete
    on FOLLOW
    for each row
begin
    -- after insert make a notification
    if :old.FOLLOW_ID is null then
        insert into NOTIFICATION(house_id, tenant_id, activity_id, notification_type)
        values (:new.house_id, :new.tenant_id, :new.follow_id, 'follow');
    end if;
    -- after delete, delete the notification
    if :new.FOLLOW_ID is null then
        delete
        from NOTIFICATION
        where ACTIVITY_ID = :old.follow_id
          and NOTIFICATION_TYPE = 'follow';
    end if;
end;
/

