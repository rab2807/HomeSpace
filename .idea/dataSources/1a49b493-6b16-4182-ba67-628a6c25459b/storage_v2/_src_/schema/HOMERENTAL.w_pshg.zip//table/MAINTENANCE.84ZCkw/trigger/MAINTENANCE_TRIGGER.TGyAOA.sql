create trigger MAINTENANCE_TRIGGER
    after insert
    on MAINTENANCE
    for each row
begin
    -- after insert make a notification
    if :old.MAINTENANCE_ID is null then
        insert into NOTIFICATION(house_id, tenant_id, activity_id, notification_type)
        values (:new.house_id, :new.tenant_id, :new.MAINTENANCE_ID, 'maintenance-issue');
    end if;
end;
/

