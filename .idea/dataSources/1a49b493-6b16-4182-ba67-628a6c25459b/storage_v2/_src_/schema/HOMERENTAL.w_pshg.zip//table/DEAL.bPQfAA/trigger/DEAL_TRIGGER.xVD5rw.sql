create trigger DEAL_TRIGGER
    after insert
    on DEAL
    for each row
begin
    -- update house vacancy info
    update HOUSE
    set VACANT = 'no'
    where HOUSE_ID = :new.HOUSE_ID;

    -- update tenant house info
    update TENANT
    set HOUSE_ID = :new.HOUSE_ID
    where TENANT_ID = :new.TENANT_ID;

    -- make a notification
    insert into NOTIFICATION(house_id, tenant_id, activity_id, notification_type)
    values (:new.house_id, :new.tenant_id, :new.deal_id, 'deal');

    -- remove all the request for the corresponding house
    delete
    from REQUEST
    where HOUSE_ID = :new.HOUSE_ID;
end;
/

