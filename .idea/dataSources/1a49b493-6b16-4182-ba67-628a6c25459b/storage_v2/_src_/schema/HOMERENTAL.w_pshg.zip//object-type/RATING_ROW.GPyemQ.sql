create type rating_row as object
(
    rating number,
    count  number
);
/

