create trigger REQUEST_TRIGGER
    after insert or delete
    on REQUEST
    for each row
begin
    -- after insert make a notification
    if :old.REQUEST_ID is null then
        insert into NOTIFICATION(house_id, tenant_id, activity_id, notification_type)
        values (:new.house_id, :new.tenant_id, :new.request_id, 'request');
    end if;
    -- after delete, delete the notification
    if :new.REQUEST_ID is null then
        delete
        from NOTIFICATION
        where ACTIVITY_ID = :old.request_id
        and NOTIFICATION_TYPE = 'request';
    end if;
end;
/

