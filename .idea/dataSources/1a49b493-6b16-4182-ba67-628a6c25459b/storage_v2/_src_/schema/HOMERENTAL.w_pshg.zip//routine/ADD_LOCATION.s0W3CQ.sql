create procedure ADD_LOCATION(id in number, lat in number, lon in number, area_ in varchar2,
                                         suburb_ in varchar2, district_ in varchar2) is
    loc_count number default 0;
begin
    select count(*)
    into loc_count
    from LOCATION
    where LOCATION_ID = id;

    if loc_count = 0 then
        insert into LOCATION(LOCATION_ID, latitude, longitude, area, suburb, district)
        VALUES (id, lat, lon, area_, suburb_, district_);
    end if;
end;
/

